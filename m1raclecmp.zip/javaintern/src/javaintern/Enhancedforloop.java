package javaintern;

public class Enhancedforloop {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		 for(int b:a) {
			 System.out.println(b);
		 }

	}

}
