package javaintern;

public class Evenupto10 {

	public static void main(String[] args) {
		int sum=0;
		int numbers[] = {1,5,2,6,7,8,3,4,9,12};
		for (int a:numbers) {
			if(a%2==0) {
				System.out.println(a);
							}
		}
	}
}
