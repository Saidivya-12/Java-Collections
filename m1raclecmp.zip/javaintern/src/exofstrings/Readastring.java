package exofstrings;
import java.util.*;

public class Readastring {
	public static void main (String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String s=sc.nextLine();
		System.out.println("the entered string is:"+ s);
	}
	

}
