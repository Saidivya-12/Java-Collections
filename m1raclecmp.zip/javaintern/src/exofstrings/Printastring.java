package exofstrings;

public class Printastring {
	public static void main(String args[]) {
		String s= "saidivya";
		for(int i=0;i<=s.length()-1;i++) {
			System.out.println(s.charAt(i));
			
			
		}
	}

}
