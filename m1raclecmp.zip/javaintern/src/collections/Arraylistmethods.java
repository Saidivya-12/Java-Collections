package collections;

import java.util.ArrayList;

public class Arraylistmethods {

	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add("one");
		al.add("two");
		al.add("three");
		//al.remove(1);
		//al.clear();
		//al.set(1,"one");
		System.out.println( al.size());
	}

}
