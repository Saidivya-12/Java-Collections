package collections;

import java.util.LinkedList;

public class Creatinglinkedlist {

	public static void main(String[] args) {
		LinkedList ll=new LinkedList();
		ll.add("java");
		ll.add("miracle");
		System.out.println(ll);
	}

}
